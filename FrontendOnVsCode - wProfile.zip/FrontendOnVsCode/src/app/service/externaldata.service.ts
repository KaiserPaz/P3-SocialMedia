import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})

export class ExternaldataService {

  _http:HttpClient;

  commentsData:any;
  postsData:any;
  usersData:any;
  userFriendData:any;

  constructor(httpClientRef:HttpClient)
  {
    this._http = httpClientRef;
  }

  getCommentsData()
  {   
    this._http.get('https://localhost:7146/api/Comments').subscribe( data => 
    {     
      this.commentsData = data; 
    })
  }

  getPostsData()
  {   
    this._http.get('https://localhost:7146/api/Posts').subscribe( data => 
    {
      this.postsData = data; 
    })
  }

  getUsersData()
  {   
    this._http.get('https://localhost:7146/api/Users').subscribe( data => 
    {
      this.usersData = data; 
    })
  }

  getUserFriendData()
  {   
    this._http.get('https://localhost:7146/api/UserFriends').subscribe( data => 
    {
      this.userFriendData = data;
    })
  }
}