import { Component, OnInit } from '@angular/core';
import { ExternaldataService } from 'src/app/service/externaldata.service';


@Component({
  selector: 'app-dashboard-page',
  templateUrl: './dashboard-page.component.html',
  styleUrls: ['./dashboard-page.component.css']
})
export class DashboardPageComponent implements OnInit {

  _externalData:ExternaldataService;

  constructor(externalDataRef:ExternaldataService){
    this._externalData = externalDataRef;
   }

  ngOnInit(): void {
  }

}
