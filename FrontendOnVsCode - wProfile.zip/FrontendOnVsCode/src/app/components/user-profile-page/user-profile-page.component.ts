import { Component, OnInit } from '@angular/core';
import { ExternaldataService } from 'src/app/service/externaldata.service';

@Component({
  selector: 'app-user-profile-page',
  templateUrl: './user-profile-page.component.html',
  styleUrls: ['./user-profile-page.component.css']
})
export class UserProfilePageComponent implements OnInit {

  _externalData:ExternaldataService;

  constructor(externalDataRef:ExternaldataService){
    this._externalData = externalDataRef;
   }

  ngOnInit(): void {
  }

}
