import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';


import { HomePageComponent } from './components/home-page/home-page.component';
import { AboutPageComponent } from './components/about-page/about-page.component';
import { SeenCommentsPageComponent } from './components/seen-comments-page/seen-comments-page.component';
import { LoginPageComponent } from './components/login-page/login-page.component';
import { SignUpPageComponent } from './components/sign-up-page/sign-up-page.component';
import { UserProfilePageComponent } from './components/user-profile-page/user-profile-page.component';

import { DashboardPageComponent } from './components/dashboard-page/dashboard-page.component';


const routes: Routes = [
  {path: '', component: HomePageComponent},
  {path: 'homePage', component: HomePageComponent},
  {path: 'aboutPage', component: AboutPageComponent},
  {path: 'seenCommentsPage', component: SeenCommentsPageComponent},
  {path: 'loginPage', component: LoginPageComponent},
  {path: 'signUpPage', component: SignUpPageComponent},
  {path: 'userProfilePage', component: UserProfilePageComponent},
  {path: 'dashboardPage', component: DashboardPageComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
